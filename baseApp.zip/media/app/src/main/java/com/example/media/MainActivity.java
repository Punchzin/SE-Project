package com.example.media;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import javax.security.auth.login.LoginException;

public class MainActivity extends AppCompatActivity {
    EditText n1,n2,n3,n4,num_f;
    Button calcular;
    TextView resultado;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        n1 = findViewById(R.id.nota1);
        n2 = findViewById(R.id.nota2);
        n3 = findViewById(R.id.nota3);
        n4 = findViewById(R.id.nota4);
        num_f = findViewById(R.id.numero_faltas);
        calcular = findViewById(R.id.btn_calcular);
        resultado = findViewById(R.id.txt_resultado);

        calcular.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Log.i("TAG", "onClick: O botão foi clicado!!!");
                calcularMedia();
            }
        });



    }

    private void calcularMedia() {
        int nota1 = Integer.parseInt(n1.getText().toString());
        int nota2 = Integer.parseInt(n2.getText().toString());
        int nota3 = Integer.parseInt(n3.getText().toString());
        int nota4 = Integer.parseInt(n4.getText().toString());
        int faltas = Integer.parseInt(num_f.getText().toString());
        int resultado = (nota1 + nota2 + nota3 + nota4)/4;

        if(resultado > 5 && faltas < 20){
            Toast.makeText(this, "Aluno Aprovado com media: " + resultado, Toast.LENGTH_SHORT).show();
        }else if(resultado <= 5 && faltas >= 20){
            Toast.makeText(this, "Aluno Reprovado com media: " + resultado, Toast.LENGTH_SHORT).show();
        };


    }
}